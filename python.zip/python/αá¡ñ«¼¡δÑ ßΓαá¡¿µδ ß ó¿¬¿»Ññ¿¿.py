import requests as req
import lxml.html
import sys
sys.setrecursionlimit(100000000)
def cycle():
    pages_get=[]
    pages=input('Введите кол-во страниц для получения: ')
    try:
        pages=int(pages)
    except ValueError:
        print('Это не число!')
        cycle()
    for x in range(1,pages+1):
        response=req.get('https://ru.wikipedia.org/wiki/Служебная:Случайная_страница')
        url=response.url
        print('страница №%s' %(x) )
        print(url)
        text=response.text
        tree=lxml.html.fromstring(response.content)
        name=tree.findtext('.//title')
        print(name)
        pages_get.append(name)
        print('')
    print(pages_get)
    cycle()
cycle()
