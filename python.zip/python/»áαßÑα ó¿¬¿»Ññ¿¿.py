import requests
from bs4 import BeautifulSoup
while True:
    page=input('Введите страницу для поиска: ')
    req='https://ru.wikipedia.org/w/index.php?search='+page
    response=requests.get(req)
    url=response.url
    soup=BeautifulSoup(response.text, 'html.parser')
    text=soup.find_all('p')
    for x in text:
        print(x.get_text())

