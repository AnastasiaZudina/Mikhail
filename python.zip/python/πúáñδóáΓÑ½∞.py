print('Привет! Я бот-угадыватель чисел. Ты загадываешь число от 1 до указанного числа, а я угадываю. Если неправильно, ты говоришь, больше или меньше.')
tried=[]
while True:
    times=input('Сколько раз сыграем(0 или меньше для бесконечной игры)? ')
    try:
        times=int(times)
        break
    except ValueError:
        print('Ой, я не могу перевести это в число')
if times<=0:
    infinite_times=True
else:
    infinite_times=False
while True:
    if infinite_times==True:
        pass
    else:
        if times>1:
            print(f'Ещё {times} игр')
        elif times==1:
            print('Это последняя игра!')
        else:
            print('Я устал играть. Пока!')
            input('')
            exit()
    while True:
        maximal=input('Введи максимальное число, которое мне нужно учитывать: ')
        try:
            maximal=int(maximal)
            break
        except ValueError:
            print('Ой, я не могу перевести это в число')
    atts=len(bin(maximal))-2
    if atts>maximal:
        atts=maximal
    print(f'Я угадаю число в диапазоне от 1 до {maximal} за {atts} попыток, если ты не будешь жульничать.')
    input('Нажми enter чтобы начать игру')
    min_num=1
    max_num=maximal
    while True:
        bot_answer=round((min_num+max_num)/2)
        print(bot_answer)
        atts-=1
        if atts!=0:
            print(f'Осталось {atts} попыток.')
        else:
            result=0
            break
        print('б - больше, м - меньше, у - угадал')
        while True:
            answer=input('Введи ответ: ')
            if answer=='б' or answer=='Б':
                answer=0
                break
            elif answer=='м' or answer=='М':
                answer=1
                break
            elif answer=='у' or answer=='У':
                answer=2
                break
            else:
                print('Введи ответ из предложеных')
        if answer==0:
            min_num=bot_answer
        elif answer==1:
            max_num=bot_answer
        elif answer==2:
            result=1
            break
        if min_num>=max_num:
            print('Ты сжульничал!')
            input()
            exit()
    if result==0:
        bot_answer=round((min_num+max_num)/2)
    print(f'Ответ: {bot_answer}')
    times-=1
    
