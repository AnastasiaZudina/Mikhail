from tkinter import *

while True:
    root = Tk()
    root.geometry('1920x1080')
    root.resizable(0, 0)
    root.mainloop()
