import socket
import time
ip='localhost'
def connect():
    client=socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    while True:
         try:
            client.connect((ip,2000))
            print('Успешное подключение')
            break
         except ConnectionRefusedError:
            print(f'Не удаётся подключится к серверу.')
         except OSError:
            pass
    hostname=socket.gethostname()
    local_ip=socket.gethostbyname(hostname)
    client.send(local_ip.encode('utf-8'))
    while True:
        try:
            message=client.recv(1024).decode('utf-8')
            if not message:
                pass
            elif message=='disconnect':
                print('Принудительное отключение от сервера через 3 секунды')
                time.sleep(1)
                print('2 секунды')
                time.sleep(1)
                print('1 секунду')
                time.sleep(1)
                exit()
            else:
                print('\nСообщение от сервера:')
                print(message)
        except ConnectionResetError:
            print('Сервер разорвал соединение. Подождите 3 секунды.')
            client.close()
            time.sleep(1)
            print('2 секунды')
            time.sleep(1)
            print('1 секунду')
            time.sleep(1)
            connect()
connect()
