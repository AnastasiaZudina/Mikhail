import random

attempts=None
max_num=None
min_num=None
num=None
infinity_atts=False

 
def adjust():
    global infinity_atts
    global attempts
    global min_num
    global max_num
    print('Привет')
    print('Введи некоторые данные перед игрой')
    while True:
        min_num=input('Минимальное число: ')
        try:
            min_num=int(min_num)
            break
        except ValueError:
            print('Ой, это не число!')
    while True:
        max_num=input('Максимальное число: ')
        try:
            max_num=int(max_num)
            break
        except ValueError:
            print('Ой, это не число!')
    while True:
        attempts=input('Кол-во попыток(0 или меньше - неограничено): ')
        try:
            attempts=int(attempts)
            break
        except ValueError:
            print('Ой, это не число!')
    if attempts<=0:
        attempts=999999999999999999999999999999999999999999999999999
        infinity_atts=True
    else:
        infinity_atts=False
    generate()
 
def generate():
    global num
    num=random.randint(min_num,max_num)
    guess()
 
def guess():
    global attempts
    while True:
        if attempts!=0:
            while True:
                guess=input('Введи число: ')
                try:
                    guess=int(guess)
                    attempts-=1
                    break
                except ValueError:
                    print('Ой, это не число!')
        else:
            print(f'Попытки кончились. Число - {num}')
            break
        if guess<num:
            print('Больше!')
            if infinity_atts==False:
                print(f'Осталось {attempts} попыток')
        elif guess>num:
            print('Меньше!')
            if infinity_atts==False:
                print(f'Осталось {attempts} попыток')
        elif guess==num:
            print('Ты выиграл!')
            break
    adjust()

adjust()
