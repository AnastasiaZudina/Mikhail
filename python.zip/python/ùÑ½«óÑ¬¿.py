class human:
    def __init__(self):
        self.height=input('Введите рост в см: ')
        self.weight=input('Введите вес в кг: ')
        self.name=input('Введите имя: ')
        self.surname=input('Введите фамилию: ')
        self.addr=input('Введите адрес: ')
        self.phone=input('Введите телефон: ')
        self.email=input('Введите email: ')
        self.also=input('Введите дополнительную информацию: ')
        if self.height=='':
            self.height='Неизвестно'
        if self.weight=='':
            self.weight='Неизвестно'
        if self.name=='':
            self.name='Неизвестно'
        if self.addr=='':
            self.addr='Неизвестно'
        if self.surname=='':
            self.surname='Неизвестно'
        if self.phone=='':
            self.phone='Неизвестно'
        if self.email=='':
            self.email='Неизвестно'
        o=open('Humans.txt','at')
        o.write('Имя:\n')
        o.write(self.name)
        o.write('\n'*2)
        o.write('Фамилия:\n')
        o.write(self.surname)
        o.write('\n'*2)
        o.write('Рост:\n')
        if self.height!='Неизвестно':
            h_to_w=self.height+'см'
            o.write(h_to_w)
        else:
            o.write(self.height)
        o.write('\n'*2)
        o.write('Вес:\n')
        if self.weight!='Неизвестно':
            w_to_w=self.weight+'кг'
            o.write(w_to_w)
        else:
            o.write(self.weight)
        o.write('\n'*2)
        o.write('Адрес:\n')
        o.write(self.addr)
        o.write('\n'*2)
        o.write('Номер телефона:\n')
        o.write(self.phone)
        o.write('\n'*2)
        o.write('Email:\n')
        o.write(self.email)
        o.write('\n'*2)
        o.write('Доп. информация:\n')
        o.write(self.also)
        o.write('\n'*3)
        o.close()
while True:
    me=human()
