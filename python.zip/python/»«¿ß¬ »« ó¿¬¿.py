import requests
from bs4 import BeautifulSoup
while True:
    page=input('Введите страницу для поиска: ')
    req='https://ru.wikipedia.org/w/index.php?search='+page
    response=requests.get(req)
    url=response.url
    soup=BeautifulSoup(response.text, 'html.parser')
    try:
        text=soup.find('p').text
        if text=='При поиске фразы в intitle:, incategory: и т. п. возьмите её в кавычки.\n':
            print('Страница не найдена')
        else:
            print('Кратко:')
            print()
            print(text)
            print('Ссылка:')
            print()
            print(url)
    except AttributeError:
        print('Что-то пошло не так')
