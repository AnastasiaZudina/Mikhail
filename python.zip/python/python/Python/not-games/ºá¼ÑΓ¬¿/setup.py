import pickle
import sys
a=open('заметки.dat','wb')
notes=['']
pickle.dump(notes,a)
sys.exit()
