import sys
import pickle
from threading import Thread

load=open('заметки.dat','rb')
note=pickle.load(load)
#save=open('заметки.dat','wb')

def print_notes():
    length=len(note)
    for x in range(1,length):
            print(note[x])
            
def add_note():
    print('Введите заметку.')
    new_note=sys.stdin.readline()
    note.append(new_note)
    
def delete_note():
    length=len(note)
    for i in range(1,length):
        print(i,note[i])
    print('Выберите номер заметки для удаления.')
    note_to_delete=sys.stdin.readline()
    try:
        note_to_delete=int(note_to_delete)
    except ValueError:
        note_to_delete=-1
    if note_to_delete>length or note_to_delete<1:
        print('Нет заметки с таким номером')
    else:
        try:
            del note[note_to_delete]
        except IndexError:
            print('Нет заметки с таким номером.')
            
def main():
    print('Главное меню.')
    print('Выберите действие.')
    print('1.Просмотреть заметки.')
    print('2.Добавить заметку.')
    print('3.Удалить заметку.')
    print('4.Выход.')
    print('Для выбора введите номер.')
    select=sys.stdin.readline()
    try:
        select=int(select)
    except ValueError:
        select=-1
    if select>4 or select<1:
        print('Нет действия с таким номером.')
        main()
    elif select==1:
        print_notes()
        main()
    elif select==2:
        add_note()
        main()
    elif select==3:
        delete_note()
        main()
    elif select==4:
        sys.exit()
def save():
    while True:
        with open("заметки.dat","wb") as f:
            pickle.dump(note, f)
        
th=Thread(target=save, args=())
th.start()
main()
