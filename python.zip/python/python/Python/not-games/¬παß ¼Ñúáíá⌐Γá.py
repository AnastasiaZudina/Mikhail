# импорт нужных штук
import time
import random
import pickle
# загрузка цены и подготовка
#file_load = open('mb price.txt', 'rb')
# Внимание!Баги!#
#price_loaded = pickle.load(file_load)
#Внимание!Баги!#
#price = int(price_loaded)
percent = 0
save = open('mb price.txt', 'wb')
# базовая цена - 1000
price=1000
# случайный цикл
direction=3
while True:
    if direction==1:
        change = random.randint(-15, 0)
    elif direction==2:
        change=random.randint(-10,5)
    elif direction==3:
        change=random.randint(-5,5)
    elif direction==4:
        change=random.randint(-5,10)
    elif direction==5:
        change=random.randint(0,15)
    direction_change=random.randint(1,10)
    if direction_change==10:
        direction=random.randint(1,5)
    if change > 0:
        change_to_show = '+' + str(change) + '%'
    elif change < 0:
        change_to_show = '-' + str(-change) + '%'
    elif change == 0:
        change_to_show = '+-' + str(change) + '%'
    percent = 1 + change / 100
    price = round(price * percent)
    Time = time.asctime()
    print(f'{Time} - {price},{change_to_show}')
    pickle.dump(price, save)
    time.sleep(300)
