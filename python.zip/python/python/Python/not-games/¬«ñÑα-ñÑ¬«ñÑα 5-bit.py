import sys
import time
import os

l_to_c={'а':'00000',
        'б':'00001',
        'в':'00010',
        'г':'00011',
        'д':'00100',
        'е':'00101',
        'ж':'00110',
        'з':'00111',
        'и':'01000',
        'й':'01001',
        'к':'01010',
        'л':'01011',
        'м':'01100',
        'н':'01101',
        'о':'01110',
        'п':'01111',
        'р':'10000',
        'с':'10001',
        'т':'10010',
        'у':'10011',
        'ф':'10100',
        'х':'10101',
        'ц':'10110',
        'ч':'10111',
        'ш':'11000',
        'щ':'11001',
        'ъ':'11010',
        'ы':'11011',
        'ь':'11100',
        'э':'11101',
        'ю':'11110',
        'я':'11111'}
c_to_l={'00000':'а',
        '00001':'б',
        '00010':'в',
        '00011':'г',
        '00100':'д',
        '00101':'е',
        '00110':'ж',
        '00111':'з',
        '01000':'и',
        '01001':'й',
        '01010':'к',
        '01011':'л',
        '01100':'м',
        '01101':'н',
        '01110':'о',
        '01111':'п',
        '10000':'р',
        '10001':'с',
        '10010':'т',
        '10011':'у',
        '10100':'ф',
        '10101':'х',
        '10110':'ц',
        '10111':'ч',
        '11000':'ш',
        '11001':'щ',
        '11010':'ъ',
        '11011':'ы',
        '11100':'ь',
        '11101':'э',
        '11110':'ю',
        '11111':'я'}

def code():
    print('Введите сообщение для шифрования.')
    print('Внимание! Символы, которых нет в русском алфавите будут удалены. Буква ё станет е, а заглавные - строчными.')
    message=(sys.stdin.readline())
    message=message.lower()
    coded_message=''
    leng=len(message)
    for x in range(0, leng):
        letter=message[x]
        if letter=='ё':
            letter='е'
        coded_letter=l_to_c.get(letter,'')
        coded_message=coded_message+coded_letter
    print('Зашифрованное сообщение:')
    print(coded_message)
def decode():
    print('Введите сообщение для расшифровки.')
    print('Внимание! Сообщение должно быть зашифровано в этой программе.')
    message=sys.stdin.readline()
    message=message.lower()
    decoded_message=''
    for x in range(0,len(message),5):
        letter=message[x:x+5]
        decoded_letter=c_to_l.get(letter,'')
        decoded_message=decoded_message+decoded_letter
    print('Расшифрованное сообщение:')
    print(decoded_message)

def info():
    print('Разработчик - Зудин Михаил')
    print('Версия - 1.3.2')
    print('email - mikzudin@gmail.com')
    print('Исходный код - https://drive.google.com/file/d/1Ugw8yNpn5X2sL1FuXxgI618fPIW1jUn0/view?usp=sharing')
    print('Копия #1')
    

def delete():
    print('''Вы уверены, что хотите удалить программу? Введите 'да' для подтверждения ''')
    delete=input('Введите ответ:')
    if delete=='да':
        path=os.path.abspath(__file__)
        os.remove(path)
    else:
        main()

def main():
    global Mode
    Mode=None
    while True:
        print('Выберите режим(1-зашифровать, 2-расшифровать, 3-информация, 4-выход, 9-удаление).')
        mode=sys.stdin.readline()
        try:
            mode=int(mode)
        except ValueError:
            main()
        if mode==1:
            Mode='code'
            break
        elif mode==2:
            Mode='decode'
            break
        elif mode==3:
            Mode='info'
            break
        elif mode==4:
            Mode='exit'
            break
        elif mode==9:
            Mode='delete'
            break
        else:
            main()
    if Mode=='code':
        code()
        main()
    elif Mode=='decode':
        decode()
        main()
    elif Mode=='info':
        info()
        main()
    elif Mode=='exit':
        exit()
    elif Mode=='delete':
        delete()

main()

