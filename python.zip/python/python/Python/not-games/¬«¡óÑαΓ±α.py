import sys

things=['nm','mcm'.
        
