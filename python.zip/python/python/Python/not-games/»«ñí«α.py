import time
import sys
import random
def all_code():
    print('введите кол-во цифр')
    nums=int(sys.stdin.readline())
    first_num=1
    last_num=int('9'*nums)
    correct=0
    while correct<10**(nums-1):
        correct=random.randint(first_num,last_num)
    attempts=0
    num_to_try=0
    a=time.time()
    print('Подождите, идёт подбор...')
    while True:
        num_to_try=random.randint(first_num,last_num)
        attempts+=1
        if num_to_try==correct:
            b=time.time()
            seconds=b-a
            print('Число подобрано - %s, попыток - %s, время - %s секунд.'%(num_to_try,attempts,seconds))
            all_code()
            break
all_code()
