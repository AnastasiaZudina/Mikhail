is_user_right=None
is_password_right=None
right_password=None
read=open('data.dat','rb')
a=read.read()
users=['User 1','User 2','User 3','admin1','admin2','system']
passwords=['qwerty','123456','password','Pelbyf1983','Pelbyf2013+','!dgb%jd$h44R4837@$^fjjh$2uj83@']
rights={'User 1':'пользователь',
        'User 2':'пользователь',
        'User 3':'пользователь',
        'admin1':'администратор',
        'admin2':'администратор',
        'system':'система'}
def login():
     username=input('Введите логин: ')
     password=input('Введите пароль:')
     try:
          if username in users:
               is_user_right=True
          else:
               is_user_right=False
          user_id=users.index(username)
          right_password=passwords[user_id]
     except ValueError:
          is_user_right=False
     if password==right_password:
         is_password_right=True
     else:
         is_password_right=False
     if is_password_right==True and is_user_right==True:
          acess_level=rights.get(username)
          print(f'Логин успешен. Уровень доступа: {acess_level}')
     else:
          print('Неверные данные')
login()
