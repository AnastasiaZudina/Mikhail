import random as r
a=r.randint(0,1)
print(a)
