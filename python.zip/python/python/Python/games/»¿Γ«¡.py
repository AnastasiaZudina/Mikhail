import random as r

field_string1=['f','f','f','f','f']
field_string2=['f','f','f','f','f']
field_string3=['f','f','p','f','f']
field_string4=['f','f','f','f','f']
field_string5=['f','f','f','f','f']
empty_string=['f','f','f','f','f']
python_coords='2,2'
python_string=None
python_column=None
def print_field():
    print(field_string1)
    print(field_string2)
    print(field_string3)
    print(field_string4)
    print(field_string5)

def move():
    exitt=input()
    global python_coords
    global python_string
    global python_column
    global empty_string
    global field_string1
    global field_string2
    global field_string3
    global field_string4
    global field_string5
    
    while True:
        direction=r.randint(1,4)
        if direction==1 and python_coords[0]=='0':
            pass
        elif direction==2 and python_coords[2]=='4':
            pass
        elif direction==3 and python_coords[0]=='4':
            pass
        elif direction==4 and python_coords[2]=='0':
            pass
        else:
            break
    python_coords1=int(python_coords[0])
    python_coords2=int(python_coords[2])
    if direction==1:
        python_coords1-=1
    elif direction==2:
        python_coords2+=1
    elif direction==3:
        python_coords1+=1
    elif direction==4:
        python_coords2-=1
    python_coords=str(python_coords1)+','+str(python_coords2)
    python_string=int(python_coords[2])
    field_string1=empty_string
    field_string2=empty_string
    field_string3=empty_string
    field_string4=empty_string
    field_string5=empty_string
    python_column=int(python_coords[2])
    if python_string==0:
        if python_column==0:
            field_string1[0]='p'
        elif python_column==1:
            field_string1[1]='p'
        elif python_column==2:
            field_string1[2]='p'
        elif python_column==3:
            field_string1[3]='p'
        elif python_column==4:
            field_string1[4]='p'
    elif python_string==1:
        if python_column==0:
            field_string2[0]='p'
        elif python_column==1:
            field_string2[1]='p'
        elif python_column==2:
            field_string2[2]='p'
        elif python_column==3:
            field_string2[3]='p'
        elif python_column==4:
            field_string2[4]='p'
    elif python_string==2:
        if python_column==0:
            field_string3[0]='p'
        elif python_column==1:
            field_string3[1]='p'
        elif python_column==2:
            field_string3[2]='p'
        elif python_column==3:
            field_string3[3]='p'
        elif python_column==4:
            field_string3[4]='p'
    elif python_string==3:
        if python_column==0:
            field_string4[0]='p'
        elif python_column==1:
            field_string4[1]='p'
        elif python_column==2:
            field_string4[2]='p'
        elif python_column==3:
            field_string4[3]='p'
        elif python_column==4:
            field_string4[4]='p'
    elif python_string==4:
        if python_column==0:
            field_string5[0]='p'
        elif python_column==1:
            field_string5[1]='p'
        elif python_column==2:
            field_string5[2]='p'
        elif python_column==3:
            field_string5[3]='p'
        elif python_column==4:
            field_string5[4]='p'
    print_field()
    if exitt!='debug':
        move()
move()
