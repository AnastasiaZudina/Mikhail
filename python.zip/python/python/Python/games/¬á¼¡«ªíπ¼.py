import random
import sys
import time
stone_chance=33
paper_chance=33
scissors_chance=33
print('выберите, чем играть(камень-к, ножницы-н, бумага-б)')
select=sys.stdin.readline()
if select!='к'or select!='н'or select!='б':
    print('И вот зачем так?')
    sys.stdin.readline()
    raise
else:
