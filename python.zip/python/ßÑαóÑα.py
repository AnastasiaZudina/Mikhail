import socket
import threading
def connect():
    server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    server.bind(('',3000))
    server.listen(0)
    connection, address=server.accept()   
    print('Подключен клиент.')
    while True:
        text=input('Введите текст: ')
        try:
            connection.send((text).encode('utf-8'))
        except ConnectionResetError or ConnectionAbortedError:
            print('Нет подключенных клиентов')
            server.close()
            connect()
connect()
def something():
    while True:
        server.accept()
th1=threading.Thread(target=something)
th1.start()
